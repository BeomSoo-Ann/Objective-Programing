#include <iostream>
#include <string>
#include <vector>
using namespace std;

class Shape {
public:
    virtual double getArea() const = 0;
};

class Circle : public Shape {
private:
    double radius;
public:
    Circle(double r) : radius(r) {}
    double getArea() const override {
        return 3.14159 * radius * radius;
    }
};

class Rectangle : public Shape {
private:
    double width, height;
public:
    Rectangle(double w, double h) : width(w), height(h) {}
    double getArea() const override {
        return width * height;
    }
};

int main() {
    const int NUM_SHAPES = 5;
    Shape* shapes[NUM_SHAPES] = {new Circle(5), new Rectangle(4, 6), new Circle(3), new Rectangle(2,3), new Circle(2.5)};
    
    for (int i = 0; i < NUM_SHAPES; i++) {
        cout << "Area of shape " << i+1 << " is " << shapes[i]->getArea() << endl;
        delete shapes[i];
    }

    return 0;
}