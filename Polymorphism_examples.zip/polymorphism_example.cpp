#include <iostream>
#include <string>
using namespace std;

class Circle {
private:
    double radius;
public:
    Circle(double r) : radius(r) {}
    double getArea() const {
        return 3.14159 * radius * radius;
    }
};

class Rectangle {
private:
    double width, height;
public:
    Rectangle(double w, double h) : width(w), height(h) {}
    double getArea() const {
        return width * height;
    }
};

int main() {
    const int NUM_CIRCLES = 3;
    Circle circles[NUM_CIRCLES] = { Circle(5), Circle(3), Circle(2.5) };

    const int NUM_RECTANGLES = 2;
    Rectangle rectangles[NUM_RECTANGLES] = { Rectangle(4, 6), Rectangle(2, 3) };

    for (int i = 0; i < NUM_CIRCLES; i++) {
        cout << "Area of circle " << i+1 << " is " << circles[i].getArea() << endl;
    }

    for (int i = 0; i < NUM_RECTANGLES; i++) {
        cout << "Area of rectangle " << i+1 << " is " << rectangles[i].getArea() << endl;
    }

    return 0;
}