#include <iostream>

using namespace std;

int main()
{
    cout << "My Name is "
         << "안범수" << endl;
}