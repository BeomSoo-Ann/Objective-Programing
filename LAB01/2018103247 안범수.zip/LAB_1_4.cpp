#include <iostream>

using namespace std;

int main()
{
    /*구현: PI를 상수(const)로 선언*/
    const double PI = 3.14;
    char ch1 = 'A' /*구현: ASCII code로 구현*/;
    char ch2 = 65 + 32 /*구현: ch1 + 숫자 형태로 구현 */;
    cout << PI << endl;
    cout << ch1 << endl;
    cout << ch2 << endl;
}
